import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HighlightStatusDirective } from '../../../../highlight-status';
import { PriorityColorPipe } from '../../../../priority-color-pipe';
import { trigger, style, animate, transition } from '@angular/animations';
import { Output, EventEmitter } from '@angular/core';
@Component({
  selector: 'app-task-list',
  standalone: true,
  imports: [CommonModule, HighlightStatusDirective, PriorityColorPipe],
  templateUrl: './task-list.component.html',
  animations: [
    trigger('fadeInOut', [
      // Entrée (ajout)
      transition(':enter', [
        style({ opacity: 0, transform: 'translateY(-10px)' }),
        animate('300ms ease-out', style({ opacity: 1, transform: 'translateY(0)' }))
      ]),
      // Sortie (suppression)
      transition(':leave', [
        animate('300ms ease-in', style({ opacity: 0, transform: 'translateY(10px)' }))
      ])
    ])
  ]
})
export class TaskListComponent {
  @Input() tasks: any[] = [];
  @Output() statusChanged = new EventEmitter<any>();
  message: string = '';
showMessage: boolean = false;

  trackById(index: number, task: any) {
    return task.id; 
  }

deleteTask(index: number) {
  this.tasks.splice(index, 1);

  // afficher message
  this.message = 'Tâche supprimée avec succès';
  this.showMessage = true;

  // cacher après 2 secondes
  setTimeout(() => {
    this.showMessage = false;
  }, 1000);
}
changeStatus(task: any) {
  if (task.status === 'En attente') {
    task.status = 'En cours';
  } else if (task.status === 'En cours') {
    task.status = 'Terminé';
  } else {
    task.status = 'En attente';
  }

  this.statusChanged.emit(task);
}
}