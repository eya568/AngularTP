import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';    
import { TaskListComponent } from '../task-list/task-list.component';
import { ProjectDetailsComponent } from '../project-details/project-details.component'; // ✅ AJOUT
import { FormsModule, NgModel } from '@angular/forms';
import { trigger, style, animate, transition } from '@angular/animations';
@Component({
  selector: 'app-project-list',
  standalone: true,
  imports: [
    CommonModule,        
    TaskListComponent,
    ProjectDetailsComponent,
    FormsModule,
    
  ],
   animations: [
    trigger('fadeInOut', [
      transition(':enter', [
        style({ opacity: 0, transform: 'translateY(-15px)' }),
        animate('300ms ease-out', style({ opacity: 1, transform: 'translateY(0)' }))
      ]),
      transition(':leave', [
        animate('300ms ease-in', style({ opacity: 0, transform: 'translateY(15px)' }))
      ])
    ])
  ],
  templateUrl: './project-list.component.html'
})
export class ProjectListComponent {
  selectedProject: any = null;
  searchTerm: string = ''; 
   message: string = '';
showMessage: boolean = false;
  projects = [
    {
      id: 1,
      name: 'Projet 1',
      description: 'Description 1',
      createdAt: new Date(),
      status: 'En cours',
      tasks: [
        { title: 'Tâche 1', priority: 'Haute', status: 'En attente' },
        { title: 'Tâche 2', priority: 'Moyenne', status: 'En cours' }
      ]
    },
    {
      id: 2,
      name: 'Projet 2',
      description: 'Description 2',
      createdAt: new Date(),
      status: 'Terminé',
      tasks: [
        { title: 'Tâche 1', priority: 'Basse', status: 'Terminé' }
      ]
    }
  ];
  selectProject(project : any){
    this.selectedProject = project;
  }
  get filteredProjects() {
  return this.projects.filter(project =>
    project.name.toLowerCase().includes(this.searchTerm.toLowerCase())
  );
}
deleteProject(index: number) {
  this.projects.splice(index, 1);

  if (this.selectedProject === this.projects[index]) {
    this.selectedProject = null;
  }
  this.message = 'Projet supprimé avec succès';
  this.showMessage = true;

  // cacher après 2 secondes
  setTimeout(() => {
    this.showMessage = false;
  }, 1000);
}
}




